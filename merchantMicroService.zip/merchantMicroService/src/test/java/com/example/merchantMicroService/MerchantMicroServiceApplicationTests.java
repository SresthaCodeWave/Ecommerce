package com.example.merchantMicroService;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class MerchantMicroServiceApplicationTests {

	@Test
	void contextLoads() {
	}

}
